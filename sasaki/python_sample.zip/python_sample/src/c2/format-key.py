# (1) 
print("私は{name}です。".format(name="ミドリ"))

# (2)
fmt = "年齢は、{age}才で、{job}をやってます。"
s = fmt.format(age=22, job="プログラマー")
print(s)

