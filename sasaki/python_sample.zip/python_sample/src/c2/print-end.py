# print()で改行しない方法
print("剣で突き刺すかのように", end="")
print("話す者がいる。", end="")
print("しかし賢い者たちの舌は", end="")
print("人をいやす。")

