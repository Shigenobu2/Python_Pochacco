for i in range(5):
    print("i=",i)
    if i >= 3 : continue;
    print("- hello!")

