# インチをセンチメートルに変換
per_inch = 2.54
inch = 8
cm = inch * per_inch
print(cm)

