# 尺からcmへの単位変換
def syaku_to_cm(syaku):
    return round(syaku * 30.303, 3)


