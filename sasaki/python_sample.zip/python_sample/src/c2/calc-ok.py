print( 30 + 5 )


