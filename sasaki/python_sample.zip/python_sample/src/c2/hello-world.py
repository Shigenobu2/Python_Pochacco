# 文字列同士を結合する
s = "Hello," + "World!"
print(s)

# 変数に入れた文字列同士を結合する
s1 = "Hello,"
s2 = "World!"
s3 = s1 + s2
print(s3)

