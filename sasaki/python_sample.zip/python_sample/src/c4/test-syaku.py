# モジュールのインポート
import syaku

# モジュールの関数を使う
v = syaku.syaku_to_cm(10)
print("10尺=", v, "cm")

v = syaku.syaku_to_cm(20)
print("20尺=", v, "cm")
