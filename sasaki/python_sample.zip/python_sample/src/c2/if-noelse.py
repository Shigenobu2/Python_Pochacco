level = 10
if level > 5:
  print("レベル5以上の人への補足アドバイス")
if level > 8:
  print("レベル8以上の人へのアドバイス")

