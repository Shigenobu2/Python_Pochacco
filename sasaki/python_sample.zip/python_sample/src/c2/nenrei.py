# 数値に説明を加えて出力
nenrei = 18
print("年齢は", nenrei, "才です")

