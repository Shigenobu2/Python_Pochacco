# 数値と文字列を結合しようとする(正しく動く例)
kion_i = 30
kion = str(kion_i)
print( "今日の気温は" + kion + "度です")

