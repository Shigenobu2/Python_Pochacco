# 特定のメンバだけをインポート
from syaku import syaku_to_cm

print("10尺=", syaku_to_cm(10), "cm")
print("20尺=", syaku_to_cm(20), "cm")

