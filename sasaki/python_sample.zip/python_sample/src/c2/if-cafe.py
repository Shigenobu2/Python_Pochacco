kion = 26
if kion >= 25:
    print("氷水を出す")
else:
    print("熱いお茶を出す")

