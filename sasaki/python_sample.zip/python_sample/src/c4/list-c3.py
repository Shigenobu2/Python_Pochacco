data = list(map(lambda x : x*2, range(1, 6)))
print(data)

