# (1) range()関数を使う場合
for i in range(1, 4):
    print(i)

print("---")

# (2) リストを使う場合
nums = [2, 4, 6]
for i in nums:
    print(i)

