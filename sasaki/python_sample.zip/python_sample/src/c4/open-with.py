with open("test.txt", mode="w", encoding="utf-8") as f:
    f.write("私は失敗したことがない。\n")
    f.write("ただ、一万通りの方法を\n見つけただけだ。\n")
