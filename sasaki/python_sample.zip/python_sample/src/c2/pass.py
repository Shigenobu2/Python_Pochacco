n = 5
if n == 3:
    pass
else:
    print(n)

