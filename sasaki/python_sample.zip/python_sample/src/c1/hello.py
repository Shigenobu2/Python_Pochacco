print("こんにちは")

