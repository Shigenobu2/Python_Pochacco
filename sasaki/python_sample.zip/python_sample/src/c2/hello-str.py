# ダブルクォートで文字列を表現
print("Hello, Python")

# シングルクォートで文字列を表現
print('Hello, Python')

