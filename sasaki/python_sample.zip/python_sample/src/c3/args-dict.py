def print_args(**args):
    print(args)

print_args(a=30, b=50, c=40)
print_args(aa="hoge", bb="fuga")

