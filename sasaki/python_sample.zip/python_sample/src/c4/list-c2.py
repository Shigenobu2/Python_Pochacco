data = [ i*2 for i in range(1, 6) ]
print(data)

