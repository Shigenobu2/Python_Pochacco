# 東京大坂まで何時間？
kyori = 507.5
jisoku = 80
jikan = kyori / jisoku
print(jikan)

