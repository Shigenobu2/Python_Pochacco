#!/usr/bin/env python3

# ヘッダ情報を出力
print("Content-Type: text/html; charset=utf-8")

# ヘッダと本体データを区切る空行
print("")

# 本体のデータを出力
print("<html><head><meta charset='utf-8'></head><body>")
print("聞くことに速く語ることに遅くあるべき")
print("</body></html>")
