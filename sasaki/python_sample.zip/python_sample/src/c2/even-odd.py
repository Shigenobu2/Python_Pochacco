num = int(input("数字は ? "))
if num % 2 == 0:
    print("偶数です")
else:
    print("奇数です")

