i = 8
while i < 5:
    print("while(in)=", i)
    i = i + 1
else:
    print("while(else)=", i)

