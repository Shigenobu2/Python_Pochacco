import os

print("script path=", __file__)
print("script dir=", os.path.dirname(__file__))

