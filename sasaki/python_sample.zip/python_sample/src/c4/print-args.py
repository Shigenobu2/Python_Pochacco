# コマンドライン引数を取得
import sys

for i, v in enumerate(sys.argv):
    print(i, v)

