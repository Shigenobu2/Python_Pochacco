fruits = ["Apple", "Banana", "Mango", "Orange"]
for i in fruits:
    print("「" + i + "」が好き!")

