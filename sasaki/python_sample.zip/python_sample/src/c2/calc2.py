print( 20 * 3 )
print( 2 * 5 // 3 )
print( (1 + 2) * 3 )

