class Hoge:
    @staticmethod
    def introduce():
        print("Hoge")

Hoge.introduce()

