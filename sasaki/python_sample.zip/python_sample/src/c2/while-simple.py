energy = 3
while energy > 0:
  print("+ 走る")
  print("| energy=", energy)
  energy -= 1 # エネルギーを1消費
