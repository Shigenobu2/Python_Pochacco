data = []
for i in range(1, 6):
    data.append(i * 2)
print(data)

