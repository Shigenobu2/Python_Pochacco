# 空のクラス
class Empty : pass

# 空のクラスのインスタンスを作成
o = Empty()

# インスタンス変数を設定
o.id = 100
o.name = "Jiro"
o.job = "Programmer"

print(o.id)
print(o.name)
