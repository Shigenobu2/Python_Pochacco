# 名前を入力
name = input("お名前は？ ")
# 挨拶を表示
print(name+"さん、こんにちは！")

