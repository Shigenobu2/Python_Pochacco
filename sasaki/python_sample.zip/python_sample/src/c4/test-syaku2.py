import mod.syaku

print("15尺", mod.syaku.syaku_to_cm(15), "cm")
print("30尺", mod.syaku.syaku_to_cm(30), "cm")

