i = 3
while i < 5:
    print("while(in)=", i)
    if i == 2: break
    i = i + 1
else:
    print("while(else)=", i)

