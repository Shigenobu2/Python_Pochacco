# PowerShell Script
python findtext.py $args

