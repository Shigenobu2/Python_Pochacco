result = []
base = [1, 2, 3]
for x in base:
    for y in base:
        result.append( (x, y) )
print(result)

