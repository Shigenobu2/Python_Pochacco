# インチをセンチメートルに変換
per_inch = 2.54
inch = 24
cm = inch * per_inch
# 文字列で説明を加える
desc = str(inch) + "インチ = " + str(cm) + "センチ"
print(desc)

