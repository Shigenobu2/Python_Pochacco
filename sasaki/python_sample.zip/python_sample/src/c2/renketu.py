# 名前と年齢を代入
name = "Jiro"
age = 19
# 文字列を連結して表示 
desc = name + "は今年で" + str(age) + "才です"
print(desc)

