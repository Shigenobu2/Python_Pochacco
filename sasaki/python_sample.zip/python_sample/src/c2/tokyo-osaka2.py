# 東京大坂まで何時間？
kyori = 507.5
jisoku = 100 
jikan = kyori / jisoku
print(jikan)

