# 台形の面積を求める
a = 2
b = 3
h = 4
daikei = (a + b) * h / 2
print("台形の面積は", daikei, "cm2")

