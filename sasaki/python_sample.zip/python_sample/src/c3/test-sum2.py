# あるクラスの国語テストの点数
points = [88, 76, 67, 43, 79, 80, 91]
sum_v = sum(points)
ave_v = sum_v / len(points)
print("合計点は", sum_v, "点")
print("平均点は", ave_v, "点")

