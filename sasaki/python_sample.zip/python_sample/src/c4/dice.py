# 6面体のサイコロ
import random

r = random.randint(1, 6)
print(r)

