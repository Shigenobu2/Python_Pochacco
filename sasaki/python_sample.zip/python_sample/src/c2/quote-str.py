# シングルクォートを文字列で使いたい場合
print("I can't speak English.")

# シングルクォートを文字列で使いたい場合
print('He said, "I play the piano".')

