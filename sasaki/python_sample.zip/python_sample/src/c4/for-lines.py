with open("mt7_7.txt", encoding="utf-8") as tf:
    for line in tf:
        print(line)

